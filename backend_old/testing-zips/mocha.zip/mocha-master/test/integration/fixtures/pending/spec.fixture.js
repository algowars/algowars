'use strict';

describe('suite', function () {
  it('pending spec');
});
