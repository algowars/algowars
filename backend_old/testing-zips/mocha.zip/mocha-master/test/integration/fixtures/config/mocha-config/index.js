'use strict';
  
// a comment
module.exports = {
  require: ['foo', 'bar'],
  bail: true,
  reporter: 'dot',
  slow: 60
};
