'use strict';

describe('a suite returning a value', function () {
  return Promise.resolve();
});
