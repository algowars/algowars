'use strict';

describe.skip('forbid pending - suite marked with skip', function() {
  it('test1', function() {});
});
