'use strict';

describe('forbid pending - all test pass', function() {
  it('test1', function() {});
  it('test2', function() {});
  it('test3', function() {});
});
