'use strict';

describe('ignore test pass', function () {
  it('should find this test', function () {});
});
