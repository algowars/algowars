export const mochaHooks = {
  beforeAll() {
    console.log('mjs beforeAll');
  },
  afterAll() {
    console.log('mjs afterAll');
  },
};
