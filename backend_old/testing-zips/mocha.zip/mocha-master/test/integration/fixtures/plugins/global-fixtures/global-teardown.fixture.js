'use strict';

exports.mochaGlobalTeardown = async function() {
  console.log('teardown schmeardown');
};
