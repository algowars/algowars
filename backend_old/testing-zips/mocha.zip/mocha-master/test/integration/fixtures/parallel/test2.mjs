import {describe,it} from "../../../../index.js";

describe('test2', () => {
  it('should pass', () => {});
});
