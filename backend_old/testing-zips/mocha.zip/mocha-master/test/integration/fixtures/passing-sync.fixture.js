'use strict';

describe('a suite', function() {
  it('should succeed', function() {
  });
});
