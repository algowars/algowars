import {assert} from './index.js';

globalThis.assert = assert;
