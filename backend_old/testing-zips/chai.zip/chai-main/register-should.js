import {should} from './index.js';

globalThis.should = should();
