import jsdoc from "eslint-plugin-jsdoc";

export default [
  jsdoc.configs["flat/recommended"],
  {
    rules: {
      "jsdoc/require-param-description": "off",
      "jsdoc/require-returns-description": "off",
      "jsdoc/tag-lines": ["error", "any", { startLines: 1 }],
    },
  },
];
