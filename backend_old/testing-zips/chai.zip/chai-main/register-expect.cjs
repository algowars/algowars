const {expect} = require('./chai.cjs');

globalThis.expect = expect;
